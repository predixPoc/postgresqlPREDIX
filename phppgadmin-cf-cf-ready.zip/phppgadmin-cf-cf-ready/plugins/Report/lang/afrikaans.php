<?php
	/**
	 * Afrikaans Language file.
	 */

	// Basic strings
	$plugin_lang['strplugindescription'] = 'Report plugin';
	$plugin_lang['strnoreportsdb'] = 'Jy het nie die verslae-databasis geskep nie. Lees asb. die INSTALL-lêer vir instruksies.';

	// Reports
	$plugin_lang['strreport'] =  'Verslag';
	$plugin_lang['strreports'] =  'Verslae';
	$plugin_lang['strshowallreports'] =  'Wys alle verslae';
	$plugin_lang['strnoreports'] =  'Geen verslae gevind.';
	$plugin_lang['strcreatereport'] =  'Skep verslag';
	$plugin_lang['strreportdropped'] =  'Verslag is verwyder.';
	$plugin_lang['strreportdroppedbad'] =  'Verwydering van verslag het misluk.';
	$plugin_lang['strconfdropreport'] =  'Is jy seker dat jy die verslag "%s" wil verwyder?';
	$plugin_lang['strreportneedsname'] =  'Jy moet \'n naam gee vir die verslag.';
	$plugin_lang['strreportneedsdef'] =  'Jy moet SQL-kode skryf vir die verslag.';
	$plugin_lang['strreportcreated'] =  'Verslag is geskep.';
	$plugin_lang['strreportcreatedbad'] =  'Die verslag kon nie geskep word nie.';
?>
